GuildThingDiscordRolesDB = {
	["members"] = {
	["Khingus"] = {
	["nick"] = "Tankkingen",
	["tag"] = "kinguskhaan",
	["roleNames"] = {
	"officer",
	"guildie",
},
},
	["Symah"] = {
	["nick"] = "Bubblekingen/Bankkingen",
	["tag"] = "dankomeme",
	["roleNames"] = {
	"trail raider",
	"pug",
	"guildie",
},
},
	["Transan"] = {
	["nick"] = "Tankkingen",
	["tag"] = "kinguskhaan",
	["roleNames"] = {
	"officer",
	"guildie",
},
},
},
}
GuildThingAuditLogDB = {
	["entries"] = {
	{
	["characterName"] = "Transan",
	["detail"] = "+guildie by bot",
	["detectedAt"] = 1787418549,
	["discordNick"] = "Tankkingen",
	["discordTag"] = "kinguskhaan",
},
	{
	["characterName"] = "Transan",
	["detail"] = "Claimed by kinguskhaan",
	["detectedAt"] = 1787418548,
	["discordNick"] = "Tankkingen",
	["discordTag"] = "kinguskhaan",
},
	{
	["characterName"] = "Khingus",
	["detail"] = "Claimed by kinguskhaan",
	["detectedAt"] = 1787418548,
	["discordNick"] = "Tankkingen",
	["discordTag"] = "kinguskhaan",
},
	{
	["characterName"] = "Transan",
	["detail"] = "-guildie by bot",
	["detectedAt"] = 1787418468,
	["discordNick"] = "Tankkingen",
	["discordTag"] = "kinguskhaan",
},
	{
	["characterName"] = "Symah",
	["detail"] = "+trail raider by kinguskhaan",
	["detectedAt"] = 1787414092,
	["discordNick"] = "Bubblekingen/Bankkingen",
	["discordTag"] = "dankomeme",
},
	{
	["characterName"] = "Symah",
	["detail"] = "+pug by kinguskhaan",
	["detectedAt"] = 1787414088,
	["discordNick"] = "Bubblekingen/Bankkingen",
	["discordTag"] = "dankomeme",
},
},
}
