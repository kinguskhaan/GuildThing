-- Written by apps/sync, NOT by this addon and NOT via SavedVariables —
-- see syncAddonDataFile in apps/sync/src/index.ts. This default (empty)
-- stub ships with the addon so DiscordRolesUI.lua/AuditLogUI.lua have
-- something valid to read even before apps/sync has ever run.
GuildThingDiscordRolesDB = {
	["members"] = {},
}
GuildThingAuditLogDB = {
	["entries"] = {},
}
